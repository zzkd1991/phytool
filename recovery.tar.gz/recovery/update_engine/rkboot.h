/*************************************************************************
    > File Name: rkboot.h
    > Author: jkand.huang
    > Mail: jkand.huang@rock-chips.com
    > Created Time: Mon 03 Jun 2019 03:46:33 PM CST
 ************************************************************************/

#ifndef _RKBOOT_H
#define _RKBOOT_H
bool download_loader(PBYTE data_buf, int size, char *dest_path);
#endif
