/*************************************************************************
    > File Name: download.h
    > Author: jkand.huang
    > Mail: jkand.huang@rock-chips.com
    > Created Time: Thu 07 Mar 2019 10:39:33 AM CST
 ************************************************************************/

#ifndef _DOWNLOAD_H
#define _DOWNLOAD_H
int download_file(char *url, const char *output_filename);
#endif
