/*
 * Copyright (C) 2013 Renesas Electronics Corporation
 *
 * SPDX-License-Identifier: GPL-2.0
 */

#ifndef __QOS_H__
#define __QOS_H__

void qos_init(void);

#endif
