#ifndef __VEXPRESS64_PCIE_H__
#define __VEXPRESS64_PCIE_H__

void vexpress64_pcie_init(void);

#endif /* __VEXPRESS64_PCIE_H__ */
