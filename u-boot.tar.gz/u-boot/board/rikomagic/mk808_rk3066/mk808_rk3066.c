/*
 * (C) Copyright 2017 Paweł Jarosz <paweljarosz3691@gmail.com>
 *
 * SPDX-License-Identifier:     GPL-2.0+
 */

#include <common.h>

DECLARE_GLOBAL_DATA_PTR;

