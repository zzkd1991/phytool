/*
 * Copyright (C) 2016 Amarula Solutions B.V.
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

#ifndef _BOARD_H_
#define _BOARD_H_
void setenv_fdt_file(void);
void setup_gpmi_nand(void);
void setup_display(void);
#endif /* _BOARD_H_ */
