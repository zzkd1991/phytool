#ifndef _EVM_H
#define _EVM_H

void enable_uart0_pin_mux(void);
void enable_mmc1_pin_mux(void);
void enable_enet_pin_mux(void);

#endif /* _EVM_H */
