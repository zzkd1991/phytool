/*
 * Currently nothing special is needed on this board, empty file to
 * make build scripts happy
 */
