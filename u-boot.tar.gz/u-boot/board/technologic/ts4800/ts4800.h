/*
 * (C) Copyright 2015 Savoir-faire Linux Inc.
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

#ifndef _TS4800_H
#define _TS4800_H

#define TS4800_SYSCON_BASE 0xb0010000

struct ts4800_wtd_regs {
	u16	feed;
};

#endif
